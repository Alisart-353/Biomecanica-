import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from './components/LanguageSwitcher';
import VideoPanel from './components/VideoPanel';
import type { Keyframe } from './lib/analysis/keyframes';

function labelToKey(label: Keyframe['label']) {
  return `phase_${label}` as const;
}

export default function App() {
  const { t } = useTranslation();
  const [frames, setFrames] = useState<Keyframe[]>([]);

  return (
    <div className="container">
      <div className="header">
        <h1 className="h1">{t('appTitle')}</h1>
        <LanguageSwitcher />
      </div>

      <div className="grid">
        <VideoPanel onFrames={setFrames} />

        <div className="card">
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <strong>{t('frames')}</strong>
            <span className="badge">{frames.length}</span>
          </div>

          {frames.length === 0 ? (
            <p className="note" style={{ marginTop: 10 }}>
              {t('autoCaptureHint')}
            </p>
          ) : (
            <div className="thumbs" style={{ marginTop: 10 }}>
              {frames.map((f) => (
                <div className="thumb" key={f.label}>
                  <img src={f.imageDataUrl} alt={f.label} />
                  <div className="meta">
                    <div>
                      <div style={{ fontWeight: 800 }}>{t(labelToKey(f.label))}</div>
                      <div className="small">t = {f.timeSec.toFixed(2)}s</div>
                    </div>
                    <a
                      className="btn"
                      href={f.imageDataUrl}
                      download={`${f.label}_${f.timeSec.toFixed(2)}s.png`}
                    >
                      {t('download')}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="note" style={{ marginTop: 12 }}>
            Sugerencia: si el video dura más de 20s, recórtalo o usa una sección específica para que la auto-captura sea más precisa.
          </div>
        </div>
      </div>

      <div className="note" style={{ marginTop: 18 }}>
        Modelo: MediaPipe Holistic Landmarker (543 puntos: 33 pose, 468 cara, 21 por mano). Fuentes: Google AI Edge.
      </div>
    </div>
  );
}
