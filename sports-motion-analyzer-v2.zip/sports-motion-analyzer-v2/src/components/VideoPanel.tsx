import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getHolistic, type HolisticConfig, type MpDelegate, type MpQuality } from '../lib/mediapipe/holistic';
import { autoCaptureKeyframes, type AutoCaptureMode, type Keyframe } from '../lib/analysis/keyframes';

type Props = {
  onFrames: (frames: Keyframe[]) => void;
};

export default function VideoPanel({ onFrames }: Props) {
  const { t } = useTranslation();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const overlayRef = useRef<HTMLCanvasElement | null>(null);

  const [src, setSrc] = useState<string | null>(null);
  const [speed, setSpeed] = useState<number>(1);
  const [delegate, setDelegate] = useState<MpDelegate>('GPU');
  const [quality, setQuality] = useState<MpQuality>('heavy');
  const [confidence, setConfidence] = useState<number>(0.7);
  const [mpState, setMpState] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [error, setError] = useState<string>('');
  const [mode, setMode] = useState<AutoCaptureMode>('bowling');
  const [busy, setBusy] = useState<boolean>(false);

  const config: HolisticConfig = useMemo(
    () => ({ delegate, quality, confidence }),
    [delegate, quality, confidence]
  );

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.playbackRate = speed;
  }, [speed]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const v = videoRef.current;
      if (!v) return;
      if (e.code === 'Space') {
        e.preventDefault();
        if (v.paused) void v.play();
        else v.pause();
      }
      if (e.code === 'ArrowRight') {
        v.currentTime = Math.min(v.duration || v.currentTime + 0.1, v.currentTime + 0.1);
      }
      if (e.code === 'ArrowLeft') {
        v.currentTime = Math.max(0, v.currentTime - 0.1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  function clearOverlay() {
    const c = overlayRef.current;
    const v = videoRef.current;
    if (!c || !v) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, c.width, c.height);
  }

  function syncOverlaySize() {
    const c = overlayRef.current;
    const v = videoRef.current;
    if (!c || !v) return;
    if (!v.videoWidth || !v.videoHeight) return;
    c.width = v.videoWidth;
    c.height = v.videoHeight;
  }

  async function ensureLandmarker() {
    try {
      setError('');
      setMpState('loading');
      const landmarker = await getHolistic(config);
      setMpState('ready');
      return landmarker;
    } catch (e: any) {
      setMpState('error');
      setError(t('errorLoad'));
      throw e;
    }
  }

  async function detectCurrentFrame() {
    const v = videoRef.current;
    const c = overlayRef.current;
    if (!v || !c || !src) return;

    const landmarker = await ensureLandmarker();
    syncOverlaySize();

    const tsMs = Math.floor(v.currentTime * 1000);
    const result = landmarker.detectForVideo(v, tsMs) as any;

    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, c.width, c.height);

    // Minimal visualization: draw pose and hands points if present.
    // (This avoids pulling in DrawingUtils; you can swap in DrawingUtils later.)
    const drawPts = (pts: any[] | undefined, radius = 3) => {
      if (!pts?.length) return;
      ctx.beginPath();
      for (const p of pts) {
        const x = p.x * c.width;
        const y = p.y * c.height;
        ctx.moveTo(x + radius, y);
        ctx.arc(x, y, radius, 0, Math.PI * 2);
      }
      ctx.fillStyle = 'rgba(0,0,0,0.75)';
      ctx.fill();
    };

    // Pose
    if (result?.poseLandmarks?.length) drawPts(result.poseLandmarks[0] ?? result.poseLandmarks);
    // Hands
    if (result?.leftHandLandmarks?.length) drawPts(result.leftHandLandmarks[0] ?? result.leftHandLandmarks, 2);
    if (result?.rightHandLandmarks?.length) drawPts(result.rightHandLandmarks[0] ?? result.rightHandLandmarks, 2);
  }

  async function runAutoCapture() {
    const v = videoRef.current;
    if (!v || !src) return;
    setBusy(true);
    try {
      const landmarker = await ensureLandmarker();
      syncOverlaySize();

      const overlayDrawer = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
        // If you want to bake overlay into exported PNGs, draw on ctx here.
        // For now we keep PNG clean (video only).
        void ctx; void w; void h;
      };

      const frames = await autoCaptureKeyframes({
        video: v,
        landmarker,
        mode,
        sampleFps: 30,
        maxDurationSec: 20,
        overlayDrawer
      });
      onFrames(frames);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div className="row">
          <label className="btn">
            {t('loadVideo')}
            <input
              type="file"
              accept="video/*"
              style={{ display: 'none' }}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const url = URL.createObjectURL(f);
                setSrc(url);
                setTimeout(() => syncOverlaySize(), 0);
              }}
            />
          </label>
          <span className="badge">
            {t('playbackSpeed')}
            <select
              className="select"
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
            >
              {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2].map((v) => (
                <option key={v} value={v}>
                  {v}x
                </option>
              ))}
            </select>
          </span>
        </div>

        <div className="row">
          <span className="badge">
            {t('mpStatus')}:&nbsp;
            {mpState === 'idle' && t('mpNotLoaded')}
            {mpState === 'loading' && t('mpLoading')}
            {mpState === 'ready' && t('mpReady')}
            {mpState === 'error' && 'Error'}
          </span>
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        {!src ? (
          <p className="note">{t('noVideo')}</p>
        ) : (
          <div className="videoWrap">
            <video
              className="videoEl"
              ref={videoRef}
              src={src}
              controls
              onLoadedMetadata={() => {
                syncOverlaySize();
                clearOverlay();
              }}
            />
            <canvas ref={overlayRef} className="canvasOverlay" />
          </div>
        )}
      </div>

      <div className="row" style={{ marginTop: 12 }}>
        <span className="badge">
          {t('delegate')}
          <select className="select" value={delegate} onChange={(e) => setDelegate(e.target.value as MpDelegate)}>
            <option value="GPU">{t('delegateGPU')}</option>
            <option value="CPU">{t('delegateCPU')}</option>
          </select>
        </span>

        <span className="badge">
          {t('modelQuality')}
          <select className="select" value={quality} onChange={(e) => setQuality(e.target.value as MpQuality)}>
            <option value="lite">{t('lite')}</option>
            <option value="full">{t('full')}</option>
            <option value="heavy">{t('heavy')}</option>
          </select>
        </span>

        <span className="badge">
          {t('confidence')}
          <select
            className="select"
            value={confidence}
            onChange={(e) => setConfidence(Number(e.target.value))}
          >
            {[0.5, 0.6, 0.7, 0.8, 0.9].map((c) => (
              <option key={c} value={c}>
                {c.toFixed(1)}
              </option>
            ))}
          </select>
        </span>

        <span className="badge">
          {t('mode')}
          <select className="select" value={mode} onChange={(e) => setMode(e.target.value as AutoCaptureMode)}>
            <option value="bowling">{t('mode_bowling')}</option>
            <option value="generic">{t('mode_generic')}</option>
          </select>
        </span>
      </div>

      {error ? <p className="error" style={{ marginTop: 10 }}>{error}</p> : null}

      <div className="row" style={{ marginTop: 12 }}>
        <button className="btn" onClick={() => void detectCurrentFrame()} disabled={!src || busy}>
          {t('detect')}
        </button>
        <button className="btn primary" onClick={() => void runAutoCapture()} disabled={!src || busy}>
          {busy ? '…' : t('autoCapture')}
        </button>
        <button className="btn" onClick={() => onFrames([])} disabled={busy}>
          {t('clear')}
        </button>
      </div>

      <p className="note" style={{ marginTop: 10 }}>{t('autoCaptureHint')}</p>
      <p className="note">{t('notes')}</p>

      <div className="card" style={{ marginTop: 12, background: '#f8fafc' }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <strong>{t('tipsTitle')}</strong>
          <span className="kbd">Space</span>
        </div>
        <div className="note" style={{ marginTop: 6 }}>{t('tips')}</div>
      </div>
    </div>
  );
}
