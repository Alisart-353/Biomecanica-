import React from 'react';
import { useTranslation } from 'react-i18next';
import { setLocale } from '../i18n';

export default function LanguageSwitcher() {
  const { i18n, t } = useTranslation();
  const current = (i18n.language || 'en').startsWith('es') ? 'es' : 'en';

  return (
    <label className="row" style={{ gap: 8 }}>
      <span className="small" style={{ fontWeight: 700 }}>{t('language')}</span>
      <select
        className="select"
        value={current}
        onChange={(e) => setLocale(e.target.value as 'es' | 'en')}
        aria-label={t('language')}
      >
        <option value="es">Español</option>
        <option value="en">English</option>
      </select>
    </label>
  );
}
