import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import es from './locales/es.json';
import en from './locales/en.json';

const saved = localStorage.getItem('sma_locale');
const browser = (navigator.language || 'en').toLowerCase();
const initial = saved || (browser.startsWith('es') ? 'es' : 'en');

void i18n
  .use(initReactI18next)
  .init({
    resources: {
      es: { translation: es },
      en: { translation: en }
    },
    lng: initial,
    fallbackLng: 'en',
    interpolation: { escapeValue: false }
  });

export function setLocale(locale: 'es' | 'en') {
  i18n.changeLanguage(locale);
  localStorage.setItem('sma_locale', locale);
}

export default i18n;
