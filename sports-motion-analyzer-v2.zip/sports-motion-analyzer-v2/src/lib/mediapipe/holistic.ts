import {
  FilesetResolver,
  HolisticLandmarker,
  type HolisticLandmarkerOptions
} from '@mediapipe/tasks-vision';

export type MpDelegate = 'GPU' | 'CPU';
export type MpQuality = 'lite' | 'full' | 'heavy';

export type HolisticConfig = {
  delegate: MpDelegate;
  quality: MpQuality;
  confidence: number; // 0..1
};

let cached: HolisticLandmarker | null = null;
let cachedKey = '';

function modelUrl(quality: MpQuality) {
  // Use the official MediaPipe model hosting. "latest" is convenient for updates.
  // Reference: community issue mentioning the holistic_landmarker.task URL pattern.
  // https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/latest/holistic_landmarker.task
  // (You can pin to /float16/1/ if you prefer strict reproducibility.)
  return 'https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/latest/holistic_landmarker.task';
}

function wasmBaseUrl() {
  // The tasks-vision WebAssembly files are published with the package.
  // Using jsDelivr is the most common approach in examples.
  return 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.15/wasm';
}

export async function getHolistic(config: HolisticConfig): Promise<HolisticLandmarker> {
  const key = JSON.stringify(config);
  if (cached && key === cachedKey) return cached;

  if (cached) {
    cached.close();
    cached = null;
    cachedKey = '';
  }

  const fileset = await FilesetResolver.forVisionTasks(wasmBaseUrl());

  const options: HolisticLandmarkerOptions = {
    baseOptions: {
      modelAssetPath: modelUrl(config.quality),
      delegate: config.delegate
    },
    runningMode: 'VIDEO',
    minPoseDetectionConfidence: config.confidence,
    minPosePresenceConfidence: config.confidence,
    minTrackingConfidence: config.confidence,
    outputFaceBlendshapes: false
  };

  const landmarker = await HolisticLandmarker.createFromOptions(fileset, options);
  cached = landmarker;
  cachedKey = key;
  return landmarker;
}
