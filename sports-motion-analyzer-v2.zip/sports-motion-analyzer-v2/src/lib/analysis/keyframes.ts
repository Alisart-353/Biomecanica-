import type { HolisticLandmarker } from '@mediapipe/tasks-vision';

export type KeyframeLabel = 'push' | 'top' | 'release' | 'follow';

export type Keyframe = {
  label: KeyframeLabel;
  timeSec: number;
  imageDataUrl: string; // PNG data URL
};

export type AutoCaptureMode = 'bowling' | 'generic';

type Point = { x: number; y: number; confidence?: number };

function movingAverage(values: number[], window = 5) {
  const out: number[] = [];
  for (let i = 0; i < values.length; i++) {
    const start = Math.max(0, i - Math.floor(window / 2));
    const end = Math.min(values.length - 1, i + Math.floor(window / 2));
    let sum = 0;
    let n = 0;
    for (let j = start; j <= end; j++) {
      sum += values[j];
      n++;
    }
    out.push(sum / n);
  }
  return out;
}

function argMin(values: number[], from = 0, to = values.length - 1) {
  let best = from;
  for (let i = from + 1; i <= to; i++) if (values[i] < values[best]) best = i;
  return best;
}

function argMax(values: number[], from = 0, to = values.length - 1) {
  let best = from;
  for (let i = from + 1; i <= to; i++) if (values[i] > values[best]) best = i;
  return best;
}

function findFirstVelocityCrossing(values: number[], threshold: number, start = 0) {
  // values is a position series; velocity is delta.
  for (let i = Math.max(1, start); i < values.length; i++) {
    const v = values[i] - values[i - 1];
    if (Math.abs(v) >= threshold) return i;
  }
  return start;
}

function pickWrist(result: any): Point | null {
  // Holistic result contains hand landmarks arrays; pick the wrist index 0.
  // Try right hand first, then left.
  const right = result?.rightHandLandmarks?.[0]?.[0] || result?.rightHandLandmarks?.[0];
  const left = result?.leftHandLandmarks?.[0]?.[0] || result?.leftHandLandmarks?.[0];

  const candidates: any[] = [];
  if (result?.rightHandLandmarks?.length) candidates.push({ side: 'R', pts: result.rightHandLandmarks[0] });
  if (result?.leftHandLandmarks?.length) candidates.push({ side: 'L', pts: result.leftHandLandmarks[0] });

  if (candidates.length) {
    // Choose the hand with higher average visibility if available.
    const score = (pts: any[]) => pts.reduce((s, p) => s + (p.visibility ?? p.presence ?? 0), 0) / Math.max(1, pts.length);
    candidates.sort((a, b) => score(b.pts) - score(a.pts));
    const wrist = candidates[0].pts[0];
    if (wrist) return { x: wrist.x, y: wrist.y, confidence: wrist.visibility ?? wrist.presence };
  }

  if (right) return { x: right.x, y: right.y };
  if (left) return { x: left.x, y: left.y };
  return null;
}

async function seek(video: HTMLVideoElement, t: number) {
  await new Promise<void>((resolve, reject) => {
    const onSeeked = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error('seek error'));
    };
    const cleanup = () => {
      video.removeEventListener('seeked', onSeeked);
      video.removeEventListener('error', onError);
    };
    video.addEventListener('seeked', onSeeked);
    video.addEventListener('error', onError);
    video.currentTime = t;
  });
}

function captureFramePng(video: HTMLVideoElement, drawOverlay?: (ctx: CanvasRenderingContext2D, w: number, h: number) => void) {
  const c = document.createElement('canvas');
  const w = video.videoWidth;
  const h = video.videoHeight;
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('no 2d ctx');
  ctx.drawImage(video, 0, 0, w, h);
  if (drawOverlay) drawOverlay(ctx, w, h);
  return c.toDataURL('image/png');
}

function toSec(ms: number) {
  return ms / 1000;
}

export async function autoCaptureKeyframes(opts: {
  video: HTMLVideoElement;
  landmarker: HolisticLandmarker;
  mode: AutoCaptureMode;
  sampleFps?: number; // default 30
  maxDurationSec?: number; // safety for very long videos
  overlayDrawer?: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
}): Promise<Keyframe[]> {
  const { video, landmarker, mode, overlayDrawer } = opts;
  const sampleFps = opts.sampleFps ?? 30;
  const maxDurationSec = Math.min(video.duration || 0, opts.maxDurationSec ?? 20);

  // Sample times (avoid the first/last 0.05s)
  const start = Math.min(0.05, maxDurationSec);
  const end = Math.max(start, maxDurationSec - 0.05);
  const step = 1 / sampleFps;

  const times: number[] = [];
  for (let t = start; t <= end; t += step) times.push(t);

  const wristY: number[] = [];

  // We run the landmarker on downsampled frames; keep it deterministic.
  const wasPaused = video.paused;
  video.pause();

  for (const t of times) {
    await seek(video, t);
    const tsMs = Math.floor(t * 1000);
    const result = landmarker.detectForVideo(video, tsMs) as any;
    const wrist = pickWrist(result);
    wristY.push(wrist ? wrist.y : Number.NaN);
  }

  // Replace NaNs with nearest valid value for continuity.
  const cleaned = wristY.slice();
  for (let i = 0; i < cleaned.length; i++) {
    if (!Number.isFinite(cleaned[i])) {
      // look left then right
      let left = i - 1;
      while (left >= 0 && !Number.isFinite(cleaned[left])) left--;
      let right = i + 1;
      while (right < cleaned.length && !Number.isFinite(cleaned[right])) right++;
      if (left >= 0 && right < cleaned.length) cleaned[i] = (cleaned[left] + cleaned[right]) / 2;
      else if (left >= 0) cleaned[i] = cleaned[left];
      else if (right < cleaned.length) cleaned[i] = cleaned[right];
      else cleaned[i] = 0.5;
    }
  }

  const smooth = movingAverage(cleaned, 7);

  // Bowling heuristic (image coordinates: y grows downward)
  // - top backswing: wrist is highest => minimal y
  // - release: wrist lowest => maximal y, generally after top
  // - push-away: first meaningful movement early
  // - follow-through: next local minimum after release (wrist goes up again)
  const topIdx = argMin(smooth, 0, smooth.length - 1);
  const releaseIdx = argMax(smooth, topIdx, smooth.length - 1);

  const pushIdx = findFirstVelocityCrossing(smooth, 0.004, 0);

  let followIdx = releaseIdx;
  if (mode === 'bowling') {
    const searchFrom = Math.min(smooth.length - 1, releaseIdx + Math.floor(0.25 / step));
    const searchTo = smooth.length - 1;
    followIdx = argMin(smooth, searchFrom, searchTo);
  } else {
    const searchFrom = Math.min(smooth.length - 1, releaseIdx + Math.floor(0.2 / step));
    followIdx = argMin(smooth, searchFrom, smooth.length - 1);
  }

  const picked: Array<{ label: KeyframeLabel; idx: number }> = [
    { label: 'push', idx: pushIdx },
    { label: 'top', idx: topIdx },
    { label: 'release', idx: releaseIdx },
    { label: 'follow', idx: followIdx }
  ];

  const frames: Keyframe[] = [];
  for (const p of picked) {
    const t = times[Math.max(0, Math.min(times.length - 1, p.idx))];
    await seek(video, t);
    const png = captureFramePng(video, overlayDrawer);
    frames.push({ label: p.label, timeSec: t, imageDataUrl: png });
  }

  if (!wasPaused) {
    void video.play();
  }

  return frames;
}
