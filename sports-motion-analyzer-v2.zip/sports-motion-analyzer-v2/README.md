# Sports Motion Analyzer (v2)

Este proyecto es una base limpia (React + Vite + TypeScript) que replica el enfoque de tu app, corrigiendo:

- **Idioma**: i18n ES/EN con selector y persistencia.
- **Captura automática de 4 frames**: heurística basada en la trayectoria de la muñeca (Holistic 543).
- **Captura manual**: descarga de frame con overlay (video + anotaciones).

## Requisitos
- Node.js 18+

## Instalar
```bash
npm install
npm run dev
```

## Modelos / IA
Se usa MediaPipe Tasks Vision HolisticLandmarker (543 puntos) y un modelo hospedado por Google.

Modelo (por defecto):
- https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/latest/holistic_landmarker.task

WASM:
- https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.15/wasm

> Si deseas fijar el modelo a una versión, cambia `latest` por `1`.

## Próximos pasos recomendados
- Sincronización real de comparación (play/pause, scrub y frame-step sincronizados)
- Auto-capture especializado por deporte (ej. bowling: push-away / top / release / follow)
- Exportar PDF 1 página con 4 frames, métricas y logo
