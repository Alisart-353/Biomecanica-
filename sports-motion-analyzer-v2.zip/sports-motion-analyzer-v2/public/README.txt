Static assets go here.
